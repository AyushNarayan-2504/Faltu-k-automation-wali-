@echo off
chcp 65001 >nul
title PDF Generator UI
cd /d "%~dp0"

echo.
echo  ============================================
echo   PDF Generator UI khul raha hai...
echo   (Internet ki zaroorat NAHI hai)
echo  ============================================
echo.

where python >nul 2>nul
if %errorlevel%==0 (
    echo  Browser apne aap khul jayega...
    echo  Band karne ke liye ye window close kar dein.
    echo.
    python app.py
    goto end
)

where py >nul 2>nul
if %errorlevel%==0 (
    echo  Browser apne aap khul jayega...
    echo  Band karne ke liye ye window close kar dein.
    echo.
    py app.py
    goto end
)

echo  [ERROR] Python nahi mila!
echo.
echo  Kya karna hai:
echo   1. python.org se Python download karke install karein.
echo   2. Install karte waqt "Add python.exe to PATH" par TICK lagayein.
echo   3. Phir is file par dobara double-click karein.
echo.

:end
pause
