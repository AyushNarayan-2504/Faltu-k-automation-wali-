# PDF Automation — Setup Guide (Hindi)

Is folder me **2 tarike** hain PDF banane ke. Jo easy lage, wo use karein:

| Tarika | Kya hai | Kaise chalana hai |
|---|---|---|
| 🖥️ **UI wala (Naya, sabse easy)** | Browser me form khulta hai — Title, Body likho, ginati chunno, PDF download karo | `python app.py` |
| 📊 **Google Sheet wala** | Sheet se data padhkar apne aap PDF banata hai | `python generate_pdf.py` |

Hindi aur English — dono bhasha ka data chalega.

---

## 🖥️ UI wala tarika (Recommended — 100% OFFLINE, bina internet ke!)

> 🔌 **Internet ki BILKUL zaroorat nahi.** Koi `pip install` nahi. Bas Python install ho — bas!
> Poora `pdf-automation` folder apne computer par copy karein aur neeche wale steps follow karein.
> (`libs` aur `fonts` folder delete NA karein — ye app ka saaman hai.)

### Chalana kaise hai?

**Windows par (sabse easy):**
1. `UI-Kholne-Ke-Liye-Double-Click.bat` par **double-click** karein.
2. Browser apne aap khul jayega. Bas! (WiFi band ho tab bhi chalega.)

**Mac/Linux par, ya manually:**
```
python app.py
```
(Mac/Linux par `python3 app.py` likhna pad sakta hai.)
Phir browser me `http://127.0.0.1:5000` kholein. Band karne ke liye `Ctrl+C`.

### UI me kya-kya hai? (4 simple steps)

1. **Kitne PDF banane hain?** — 1 se 100 tak number likhein.
2. **Saare Titles** — Har line me ek title. Jaise 5 PDF chahiye to 5 lines likhein.
   Live counter batayega "3 / 5 titles". Kam likhe to baaki naam apne aap ban jayenge.
3. **Body** — 2 option:
   - *Sabhi PDF me SAME body* → ek baar likho, sab me jayega.
   - *Har PDF ki ALAG body* → jitne PDF, utne body ke box khul jayenge.
4. **PDF Banayein** button dabayein →
   - ⬇️ **ZIP download** (saare ek saath), ya
   - Alag-alag PDF download karein, ya
   - 👁️ **Preview** se har PDF ko browser me hi dekh lein (bilkul PDF jaisa dikhega).
   - Files `output/batch-...` folder me bhi save rehti hain.

---

## Step 1: Python install karein (sirf pehli baar)

- **Windows:** [python.org](https://www.python.org/downloads/) se Python download karke install karein.
  ⚠️ Install karte waqt **"Add Python to PATH"** wala tick zaroor lagayein.
- **Mac/Linux:** Pehle se hota hai. Terminal me `python3 --version` likhkar check karein.

> Koi library install karne ki zaroorat **nahi** — `libs` folder me sab pehle se rakha hai.

## Step 2: Google Sheet taiyaar karein

1. Apna Google Sheet kholein.
2. **Pehli row me column ke naam** likhein, jaise: `Name | Phone | City | Amount | Date`
3. Neeche rows me data bharein.
4. Upar **Share** button dabayein → **"Anyone with the link"** select karein → **Copy link**.

> 🔒 Sheet "Viewer" mode par hi rakhein. Script sirf data *padhta* hai, Sheet me kuch badalta nahi.

## Step 3: Script me Sheet ka link dalein

1. `generate_pdf.py` file ko Notepad me kholein.
2. Upar **SETTINGS** me ye line milegi:
   ```python
   SHEET_LINK = ""
   ```
3. Apna copy kiya hua link quotes ke andar paste karein:
   ```python
   SHEET_LINK = "https://docs.google.com/spreadsheets/d/1abc...xyz/edit"
   ```
4. Chahein to `PDF_TITLE` bhi badal lein (jaise `"Invoice"`, `"Salary Slip"`).
5. File save karke band karein.

## Step 4: Chalayein — bas ek command! 🎉

Script wale folder me terminal/command prompt kholkar likhein:

```
python generate_pdf.py
```

(Windows par `python`, Mac/Linux par `python3` likhna pad sakta hai.)

PDF files **`output` folder** me ban jayengi. Bas!

---

## ⚙️ Settings ki poori jaankari

| Setting | Matlab | Example |
|---|---|---|
| `SHEET_LINK` | Google Sheet ka share link | `"https://docs.google.com/..."` |
| `PDF_TITLE` | PDF ke upar bada heading | `"Invoice"`, `"Report"` |
| `MODE` | `"one_per_row"` = har row ka alag PDF. `"single"` = sabka ek hi PDF | `"one_per_row"` |
| `FILENAME_COLUMN` | PDF file ka naam kis column se bane | `"Name"` |
| `OUTPUT_FOLDER` | PDF kahan save ho | `"output"` |

## ❓ Aam dikkat aur hal

- **"Sheet download nahi ho payi"** → Sheet Share settings me "Anyone with the link" ON karein.
- **Hindi text nahi dikh raha** → `fonts` folder script ke saath hi rakhein, delete na karein.
- **`pip` nahi mil raha (Windows)** → Python dobara install karein, "Add to PATH" tick karke.
- **Bahut saare columns hain** → `MODE = "single"` rakhein, table landscape me banega.

## 📁 Folder me kya-kya hai

| File | Kaam |
|---|---|
| `generate_pdf.py` | ⭐ Main script — ise chalana hai |
| `sample_data.csv` | Demo data — Sheet ka link khaali ho to isi se PDF banta hai |
| `fonts/` | Hindi + English fonts — isi folder me rakhein |
| `output/` | Yahan bane hue PDF milenge |
| `requirements.txt` | Zaroori library ki list |
| `SETUP_GUIDE.md` | Ye guide |
