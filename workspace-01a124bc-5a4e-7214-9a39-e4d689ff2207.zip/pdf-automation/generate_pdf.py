# -*- coding: utf-8 -*-
"""
PDF Automation Script
=====================
Google Sheet (ya CSV file) se data padhkar simple PDF banata hai.

Chalane ka tarika:
    1. Neeche SETTINGS me apna Google Sheet ka link dalein
    2. Run karein:  python generate_pdf.py
    3. PDF files 'output' folder me mil jayengi

Google Sheet ka link kaise nikalein, ye SETUP_GUIDE.md me step-by-step likha hai.
"""

import csv
import os
import re
import sys
import urllib.request
import warnings
from datetime import datetime

# --- Apne folder ki library use karo (libs me fpdf2 + fonttools rakhe hain) ---
# Isse 'pip install' aur internet ki zaroorat khatam ho jaati hai.
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "libs"))
warnings.filterwarnings("ignore", message="Pillow could not be imported.*")
warnings.filterwarnings("ignore", message="defusedxml could not be imported.*")

from fpdf import FPDF

# =====================================================
#  ⚙️  SETTINGS - Sirf yahi badalna hai
# =====================================================

# 1. Apne Google Sheet ka link yahan dalein (quotes ke andar).
#    Sheet ko "Anyone with the link can view" share karna zaroori hai.
#    Agar khaali ("") rakhenge to sample_data.csv se demo PDF banega.
SHEET_LINK = ""

# 2. PDF ke upar bada title kya likha aaye
PDF_TITLE = "Report"

# 3. PDF kaise bane? Do option hain:
#      "one_per_row"  -> Har row ka alag PDF (jaise har vyakti ka alag letter)
#      "single"       -> Saari rows ka ek hi PDF (ek saath poori list/table)
MODE = "one_per_row"

# 4. Har PDF file ka naam kis column se bane? (column ka naam likhein)
#    Jaise "Name" likhne se Ramesh.pdf, Suresh.pdf banega.
FILENAME_COLUMN = "Name"

# 5. PDF kahan save ho
OUTPUT_FOLDER = "output"

# =====================================================
#  Neeche ka code - badalne ki zaroorat nahi
# =====================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
FONT_LATIN = os.path.join(SCRIPT_DIR, "fonts", "NotoSans.ttf")
FONT_LATIN_B = os.path.join(SCRIPT_DIR, "fonts", "NotoSans-Bold.ttf")
FONT_DEVA = os.path.join(SCRIPT_DIR, "fonts", "NotoSansDevanagari.ttf")
FONT_DEVA_B = os.path.join(SCRIPT_DIR, "fonts", "NotoSansDevanagari-Bold.ttf")
FONT_DEJAVU = os.path.join(SCRIPT_DIR, "fonts", "DejaVuSans.ttf")


def sheet_link_to_csv_url(link):
    """Google Sheet ke share link ko CSV download link me badalta hai."""
    match = re.search(r"/spreadsheets/d/([a-zA-Z0-9-_]+)", link)
    if not match:
        return None
    sheet_id = match.group(1)
    gid_match = re.search(r"[#&]gid=(\d+)", link)
    gid = gid_match.group(1) if gid_match else "0"
    return f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv&gid={gid}"


def load_rows():
    """Google Sheet ya local CSV se data padhta hai. Returns: list of dicts."""
    if SHEET_LINK.strip():
        csv_url = sheet_link_to_csv_url(SHEET_LINK.strip())
        if not csv_url:
            print("❌ Sheet ka link samajh nahi aaya. Sahi Google Sheet link dalein.")
            sys.exit(1)
        print("📥 Google Sheet se data download ho raha hai...")
        try:
            req = urllib.request.Request(csv_url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                text = resp.read().decode("utf-8-sig")
        except Exception as e:
            print(f"❌ Sheet download nahi ho payi: {e}")
            print("   Check karein: Sheet 'Anyone with the link can view' par shared hai?")
            sys.exit(1)
        rows = list(csv.DictReader(text.splitlines()))
    else:
        sample = os.path.join(SCRIPT_DIR, "sample_data.csv")
        print(f"📥 Demo mode: {sample} se data liya ja raha hai...")
        with open(sample, encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))

    # Khali rows hatao
    rows = [r for r in rows if any((v or "").strip() for v in r.values())]
    if not rows:
        print("❌ Data me koi row nahi mili. Sheet khaali to nahi?")
        sys.exit(1)
    print(f"✅ {len(rows)} rows mili. Columns: {', '.join(rows[0].keys())}")
    return rows


class SimplePDF(FPDF):
    def setup_font(self):
        # English font + Hindi (Devanagari) fallback taaki dono bhasha chale
        # Regular ke saath Bold bhi load hota hai (H1 title ke liye)
        try:
            if os.path.exists(FONT_LATIN):
                self.add_font("Noto", "", FONT_LATIN)
                has_bold = False
                if os.path.exists(FONT_LATIN_B):
                    self.add_font("Noto", "B", FONT_LATIN_B)
                    has_bold = True
                fallbacks = []
                if os.path.exists(FONT_DEVA):
                    self.add_font("NotoDeva", "", FONT_DEVA)
                    if os.path.exists(FONT_DEVA_B):
                        self.add_font("NotoDeva", "B", FONT_DEVA_B)
                    fallbacks.append("NotoDeva")
                if os.path.exists(FONT_DEJAVU):
                    # Symbols (✈ ℡ ◊ ¿ ...) ke liye extra fallback font
                    self.add_font("DejaVu", "", FONT_DEJAVU)
                    fallbacks.append("DejaVu")
                if fallbacks:
                    self.set_fallback_fonts(fallbacks)
                self.set_font("Noto", size=11)
                self.font_name = "Noto"
                self.has_bold = has_bold
                return
        except Exception as e:
            print(f"   (Font load nahi hua, default font use hoga: {e})")
        self.set_font("Helvetica", size=11)
        self.font_name = "Helvetica"
        self.has_bold = True  # Helvetica me bold pehle se hota hai

    def header_box(self, title):
        # Bilkul saada title - normal kaala text, bold nahi. (Neela box / date-time nahi)
        self.set_text_color(0, 0, 0)
        self.set_font(self.font_name, style="", size=18)
        self.multi_cell(0, 10, str(title or "Document"), new_x="LMARGIN", new_y="NEXT")
        self.ln(6)

    def key_value_table(self, row):
        self.set_font(self.font_name, size=11)
        for key, value in row.items():
            if key is None:
                continue
            self.set_fill_color(235, 240, 250)
            self.set_font(self.font_name, size=11)
            self.cell(55, 9, f"  {key}", border=1, fill=True)
            self.cell(0, 9, f"  {value or ''}", border=1,
                      new_x="LMARGIN", new_y="NEXT")

    def data_table(self, rows):
        if not rows:
            return
        cols = list(rows[0].keys())
        col_w = 190 / max(len(cols), 1)
        # Header
        self.set_fill_color(30, 60, 120)
        self.set_text_color(255, 255, 255)
        self.set_font(self.font_name, size=10)
        for c in cols:
            self.cell(col_w, 9, f" {c}", border=1, fill=True)
        self.ln()
        # Rows
        self.set_text_color(0, 0, 0)
        self.set_font(self.font_name, size=10)
        fill = False
        for r in rows:
            if fill:
                self.set_fill_color(240, 244, 252)
            for c in cols:
                self.cell(col_w, 8, f" {(r.get(c) or '')[:30]}", border=1, fill=fill)
            self.ln()
            fill = not fill


def safe_filename(text, fallback):
    text = (text or "").strip() or fallback
    text = re.sub(r'[\\/*?:"<>|]', "", text).strip()
    return text if text else fallback


def make_one_per_row(rows):
    for i, row in enumerate(rows, start=1):
        pdf = SimplePDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.setup_font()
        pdf.add_page()
        pdf.header_box(PDF_TITLE)
        pdf.key_value_table(row)
        name = safe_filename(row.get(FILENAME_COLUMN), f"row-{i}")
        path = os.path.join(SCRIPT_DIR, OUTPUT_FOLDER, f"{name}.pdf")
        pdf.output(path)
        print(f"   📄 {name}.pdf")


def make_single(rows):
    pdf = SimplePDF(orientation="L")  # landscape taaki table ache se aaye
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.setup_font()
    pdf.add_page()
    pdf.header_box(f"{PDF_TITLE}  (Total: {len(rows)})")
    pdf.data_table(rows)
    path = os.path.join(SCRIPT_DIR, OUTPUT_FOLDER, "report.pdf")
    pdf.output(path)
    print("   📄 report.pdf")


def main():
    print("=" * 50)
    print("  PDF Automation - shuru ho raha hai...")
    print("=" * 50)
    rows = load_rows()
    os.makedirs(os.path.join(SCRIPT_DIR, OUTPUT_FOLDER), exist_ok=True)
    print(f"🖨️  PDF ban rahe hain (mode: {MODE})...")
    if MODE == "single":
        make_single(rows)
    else:
        make_one_per_row(rows)
    print("=" * 50)
    print(f"  ✅ Ho gaya! PDF '{OUTPUT_FOLDER}' folder me hain.")
    print("=" * 50)


if __name__ == "__main__":
    main()
