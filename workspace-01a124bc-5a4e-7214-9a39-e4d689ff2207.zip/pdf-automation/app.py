# -*- coding: utf-8 -*-
"""
PDF Generator UI  (100% OFFLINE - bina internet ke chalta hai)
================================================================
- Koi 'pip install' nahi chahiye. Sirf Python hona chahiye.
- Saari zaroori library 'libs' folder me pehle se rakhi hai.
- Internet ki bilkul zaroorat nahi - apne computer par hi chalta hai.

Chalane ka tarika:
    Windows : UI-Kholne-Ke-Liye-Double-Click.bat par double-click karein
    Manual  : python app.py
Phir browser apne aap khul jayega. (Na khule to http://127.0.0.1:5000 kholein)
Band karne ke liye terminal me Ctrl+C dabayein.
"""

import html
import io
import json
import os
import re
import sys
import warnings
import webbrowser
import zipfile
from datetime import datetime
from threading import Timer
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote, quote

# --- Apne folder ki library use karo (libs me fpdf2 + fonttools rakhe hain) ---
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(SCRIPT_DIR, "libs"))
warnings.filterwarnings("ignore", message="Pillow could not be imported.*")
warnings.filterwarnings("ignore", message="defusedxml could not be imported.*")

from generate_pdf import SimplePDF, safe_filename  # noqa: E402

OUTPUT_DIR = os.path.join(SCRIPT_DIR, "output")
PORT = 5000

# =====================================================
#  HTML Pages (poora design isi file me hai)
# =====================================================

FORM_PAGE = """<!DOCTYPE html>
<html lang="hi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PDF Generator</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', Arial, sans-serif; background: linear-gradient(135deg, #1e3c72, #2a5298);
         min-height: 100vh; padding: 20px; color: #333; }
  .box { max-width: 700px; margin: 0 auto; }
  h1 { color: #fff; text-align: center; margin-bottom: 5px; font-size: 28px; }
  .sub { color: #cfe0ff; text-align: center; margin-bottom: 20px; font-size: 14px; }
  .card { background: #fff; border-radius: 14px; padding: 20px; margin-bottom: 15px;
          box-shadow: 0 4px 15px rgba(0,0,0,.25); }
  .card h2 { font-size: 17px; color: #1e3c72; margin-bottom: 12px; }
  .step { display: inline-block; background: #1e3c72; color: #fff; width: 26px; height: 26px;
          border-radius: 50%; text-align: center; line-height: 26px; font-size: 14px; margin-right: 8px; }
  label { display: block; font-size: 13px; color: #555; margin-bottom: 6px; }
  input[type=number] { width: 100%; padding: 12px; font-size: 18px; border: 2px solid #ddd;
          border-radius: 10px; }
  input[type=number]:focus, textarea:focus { border-color: #2a5298; outline: none; }
  textarea { width: 100%; padding: 12px; font-size: 15px; border: 2px solid #ddd;
          border-radius: 10px; font-family: inherit; resize: vertical; }
  .hint { font-size: 12px; color: #888; margin-top: 6px; }
  .counter { font-size: 13px; font-weight: bold; margin-top: 6px; }
  .ok { color: #1a9e4b; } .warn { color: #d9534f; }
  .radio-row { display: flex; gap: 10px; margin-bottom: 12px; flex-wrap: wrap; }
  .radio-pill { flex: 1; min-width: 200px; border: 2px solid #ddd; border-radius: 10px;
          padding: 10px; text-align: center; cursor: pointer; font-size: 14px; }
  .radio-pill input { margin-right: 6px; }
  .radio-pill.active { border-color: #2a5298; background: #eaf1ff; font-weight: bold; }
  .dyn-label { font-size: 13px; font-weight: bold; color: #1e3c72; margin: 10px 0 4px; }
  .btn { display: block; width: 100%; padding: 16px; font-size: 19px; font-weight: bold; color: #fff;
         background: linear-gradient(135deg, #1a9e4b, #0f7a38); border: none; border-radius: 14px;
         cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,.3); }
  .btn:hover { transform: scale(1.01); }
  .check-row { display: flex; align-items: center; gap: 8px; font-size: 14px; margin-top: 10px; }
  .check-row input { width: 18px; height: 18px; }
  .error { background: #fde8e8; border: 2px solid #d9534f; color: #b52b27; border-radius: 10px;
           padding: 12px; margin-bottom: 15px; font-size: 14px; }
  .offline { text-align:center; margin-top: 10px; font-size: 12px; color: #cfe0ff; }
</style>
</head>
<body>
<div class="box">
  <h1>📄 PDF Generator</h1>
  <p class="sub">Title + Body likhiye, ginati chuniye, PDF taiyaar!</p>

  %%ERROR_BLOCK%%

  <form method="post" action="/generate">
    <div class="card">
      <h2><span class="step">1</span> Kitne PDF banane hain?</h2>
      <input type="number" name="count" id="count" value="%%COUNT%%" min="1" max="100">
      <p class="hint">1 se 100 tak koi bhi number chun sakte hain.</p>
    </div>

    <div class="card">
      <h2><span class="step">2</span> Saare Titles yahan likhein</h2>
      <label>Har line me <b>ek title</b> likhein (Pehli line = Pehle PDF ka title)</label>
      <textarea name="titles" id="titles" rows="5" placeholder="Jaise:&#10;Meri Pehli PDF&#10;Meri Doosri PDF&#10;Meri Teesri PDF">%%TITLES%%</textarea>
      <p class="counter" id="titleCounter"></p>
      <p class="hint">💡 Kam titles likhe to baaki PDF ka naam "PDF 4", "PDF 5"... apne aap ban jayega.</p>
    </div>

    <div class="card">
      <h2><span class="step">3</span> Body likhein</h2>
      <div class="radio-row">
        <label class="radio-pill active" id="pillSame">
          <input type="radio" name="body_mode" value="same" checked> Sabhi PDF me SAME body
        </label>
        <label class="radio-pill" id="pillDiff">
          <input type="radio" name="body_mode" value="different"> Har PDF ki ALAG body
        </label>
      </div>
      <div id="sameBox">
        <textarea name="body_same" rows="7" placeholder="Yahan body ka text likhein... Ye text sabhi PDFs me aayega.">%%BODY_SAME%%</textarea>
      </div>
      <div id="diffBox" style="display:none">
        <p class="hint">Neeche har PDF ke liye alag body likhein:</p>
        <div id="diffBodies"></div>
      </div>
    </div>

    <div class="card">
      <h2><span class="step">4</span> Taiyaar? Button dabayein! 🚀</h2>
      <label class="check-row">
        <input type="checkbox" name="add_number" checked> File ke naam ke aage number lagayein (01-, 02-...)
      </label>
      <br>
      <button type="submit" class="btn">🚀 PDF Banayein</button>
    </div>
  </form>
  <p class="offline">🔌 Ye app bina internet ke aapke computer par chal raha hai</p>
</div>

<script>
  var countInput = document.getElementById('count');
  var titlesInput = document.getElementById('titles');
  var counter = document.getElementById('titleCounter');
  var diffBox = document.getElementById('diffBox');
  var sameBox = document.getElementById('sameBox');
  var diffBodies = document.getElementById('diffBodies');
  var savedBodies = {};

  function getCount() {
    var n = parseInt(countInput.value) || 1;
    if (n < 1) n = 1;
    if (n > 100) n = 100;
    return n;
  }

  function updateCounter() {
    var lines = titlesInput.value.split('\\n').filter(function(l){ return l.trim() !== ''; });
    var need = getCount();
    if (lines.length === need) {
      counter.innerHTML = '✅ ' + lines.length + ' / ' + need + ' titles — perfect!';
      counter.className = 'counter ok';
    } else if (lines.length < need) {
      counter.innerHTML = '✏️ ' + lines.length + ' / ' + need + ' titles likhe hain';
      counter.className = 'counter warn';
    } else {
      counter.innerHTML = '✅ ' + lines.length + ' titles (pehle ' + need + ' use honge)';
      counter.className = 'counter ok';
    }
  }

  function buildDiffBodies() {
    var old = diffBodies.querySelectorAll('textarea');
    for (var i = 0; i < old.length; i++) { savedBodies[i] = old[i].value; }
    var n = getCount();
    var html = '';
    for (var j = 0; j < n; j++) {
      var val = savedBodies[j] || '';
      html += '<p class="dyn-label">Body ' + (j+1) + ' (PDF ' + (j+1) + ' ke liye)</p>';
      html += '<textarea name="body_' + (j+1) + '" rows="4" placeholder="PDF ' + (j+1) + ' ki body yahan likhein...">' + val.replace(/</g,'&lt;') + '</textarea>';
    }
    diffBodies.innerHTML = html;
  }

  document.querySelectorAll('input[name=body_mode]').forEach(function(r){
    r.addEventListener('change', function(){
      var same = (this.value === 'same');
      sameBox.style.display = same ? 'block' : 'none';
      diffBox.style.display = same ? 'none' : 'block';
      document.getElementById('pillSame').className = 'radio-pill' + (same ? ' active' : '');
      document.getElementById('pillDiff').className = 'radio-pill' + (same ? '' : ' active');
      if (!same) buildDiffBodies();
    });
  });

  countInput.addEventListener('input', function(){
    updateCounter();
    if (diffBox.style.display !== 'none') buildDiffBodies();
  });
  titlesInput.addEventListener('input', updateCounter);
  updateCounter();
</script>
</body>
</html>
"""

RESULT_PAGE = """<!DOCTYPE html>
<html lang="hi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PDF Taiyaar!</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', Arial, sans-serif; background: linear-gradient(135deg, #0f7a38, #1a9e4b);
         min-height: 100vh; padding: 20px; color: #333; }
  .box { max-width: 700px; margin: 0 auto; }
  h1 { color: #fff; text-align: center; margin-bottom: 20px; font-size: 26px; }
  .card { background: #fff; border-radius: 14px; padding: 20px; margin-bottom: 15px;
          box-shadow: 0 4px 15px rgba(0,0,0,.25); }
  .zip-btn { display: block; width: 100%; padding: 16px; font-size: 18px; font-weight: bold; color: #fff;
         background: linear-gradient(135deg, #1e3c72, #2a5298); border: none; border-radius: 12px;
         cursor: pointer; text-align: center; text-decoration: none; margin-bottom: 12px; }
  .back-btn { display: block; width: 100%; padding: 13px; font-size: 16px; color: #1e3c72;
         background: #eaf1ff; border: 2px solid #1e3c72; border-radius: 12px;
         cursor: pointer; text-align: center; text-decoration: none; font-weight: bold; }
  table { width: 100%; border-collapse: collapse; font-size: 14px; }
  th { background: #1e3c72; color: #fff; padding: 10px; text-align: left; }
  td { padding: 9px 10px; border-bottom: 1px solid #eee; }
  tr:nth-child(even) td { background: #f5f8ff; }
  a.dl { color: #0f7a38; font-weight: bold; text-decoration: none; white-space: nowrap; }
  a.dl:hover { text-decoration: underline; }
  a.pv { color: #1e3c72; font-weight: bold; text-decoration: none; white-space: nowrap; }
  a.pv:hover { text-decoration: underline; }
  .note { background: #fff8e1; border: 1px solid #f0c36d; border-radius: 8px; padding: 10px;
          font-size: 13px; margin-top: 10px; }
</style>
</head>
<body>
<div class="box">
  <h1>✅ %%TOTAL%% PDF taiyaar ho gaye!</h1>
  <div class="card">
    <a class="zip-btn" href="/download-zip/%%BATCH%%">⬇️ Saare PDF ek saath download karein (ZIP)</a>
    <a class="back-btn" href="/">← Naye PDF banayein</a>
    %%NOTES_BLOCK%%
    <p style="font-size:12px;color:#666;margin-top:10px;">💡 <b>👁️ Preview</b> dabakar har PDF dekh sakte hain. (Preview wali screen me download block ho to ghabrayein nahi — apne computer par chalane par download bilkul kaam karega.)</p>
  </div>
  <div class="card">
    <table>
      <tr><th>#</th><th>File</th><th>Preview</th><th>Download</th></tr>
      %%ROWS%%
    </table>
  </div>
</div>
</body>
</html>
"""

PREVIEW_PAGE = """<!DOCTYPE html>
<html lang="hi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Preview - %%FILENAME%%</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', Arial, sans-serif; background: #525659;
         min-height: 100vh; padding: 20px; color: #333; }
  .box { max-width: 700px; margin: 0 auto; }
  .topbar { display: flex; gap: 10px; margin-bottom: 12px; flex-wrap: wrap; }
  .topbar a { flex: 1; min-width: 120px; text-align: center; padding: 11px; border-radius: 10px;
              text-decoration: none; font-weight: bold; font-size: 14px; }
  .back { background: #fff; color: #1e3c72; }
  .nav { background: #1e3c72; color: #fff; }
  .nav.disabled { background: #888; color: #ddd; pointer-events: none; }
  .paper { background: #fff; border-radius: 6px; box-shadow: 0 4px 20px rgba(0,0,0,.5);
           overflow: hidden; padding: 44px 72px; }
  .pdf-title { color: #000; font-size: 24px; font-weight: normal; line-height: 1.3;
               margin-bottom: 14px; word-wrap: break-word; }
  .pdf-body { font-size: 15px; line-height: 1.65;
              white-space: pre-wrap; word-wrap: break-word; }
  @media (max-width: 600px) {
    .paper { padding: 28px 22px; }
    .pdf-title { font-size: 20px; }
  }
  .note { background: #fff8e1; border: 1px solid #f0c36d; border-radius: 10px; padding: 10px;
          font-size: 13px; margin-top: 12px; }
  .count { text-align: center; color: #eee; font-size: 13px; margin-top: 10px; }
</style>
</head>
<body>
<div class="box">
  <div class="topbar">
    <a class="back" href="/result/%%BATCH%%">← Saari files</a>
    <a class="nav %%PREV_DISABLED%%" href="%%PREV_URL%%">← Pichhli</a>
    <a class="nav %%NEXT_DISABLED%%" href="%%NEXT_URL%%">Agli →</a>
  </div>
  <div class="paper">
    <div class="pdf-title">%%TITLE%%</div>
    <div class="pdf-body">%%BODY%%</div>
  </div>
  <div class="note">💡 Ye PDF ka <b>preview</b> hai — asli PDF file bilkul aisi hi dikhegi. Apne computer par <b>⬇️ Download</b> se original PDF file le sakte hain.</div>
  <p class="count">PDF %%IDX%% / %%TOTAL%%</p>
</div>
</body>
</html>
"""

# =====================================================
#  PDF banane ka function
# =====================================================

def build_pdf(title, body):
    """Title + Body se ek PDF banakar bytes me deta hai."""
    pdf = SimplePDF()
    # 1 inch = 25.4 mm : left, right (aur top) margin 1 inch
    pdf.set_margins(25.4, 25.4, 25.4)
    pdf.set_auto_page_break(auto=True, margin=25.4)
    pdf.setup_font()
    pdf.add_page()
    pdf.header_box(title or "Document")
    if (body or "").strip():
        pdf.set_font(pdf.font_name, size=12)
        pdf.multi_cell(0, 7, body.strip())
    buf = io.BytesIO()
    pdf.output(buf)
    return buf.getvalue()


def render_form(error="", count=3, titles="", body_same=""):
    page = FORM_PAGE
    if error:
        page = page.replace("%%ERROR_BLOCK%%", f'<div class="error">⚠️ {html.escape(error)}</div>')
    else:
        page = page.replace("%%ERROR_BLOCK%%", "")
    page = page.replace("%%COUNT%%", str(count))
    page = page.replace("%%TITLES%%", html.escape(titles))
    page = page.replace("%%BODY_SAME%%", html.escape(body_same))
    return page


def render_result(total, batch, files, notes):
    rows = []
    for i, f in enumerate(files, start=1):
        rows.append(
            f'<tr><td>{i}</td><td>{html.escape(f)}</td>'
            f'<td><a class="pv" href="/preview/{quote(batch)}/{i}">👁️ Preview</a></td>'
            f'<td><a class="dl" href="/download/{quote(batch)}/{quote(f)}">⬇️ Download</a></td></tr>'
        )
    page = RESULT_PAGE.replace("%%TOTAL%%", str(total))
    page = page.replace("%%BATCH%%", quote(batch))
    page = page.replace("%%ROWS%%", "\n".join(rows))
    if notes:
        notes_html = "<br>".join(html.escape(n) for n in notes)
        page = page.replace("%%NOTES_BLOCK%%",
                            f'<div class="note">💡 <b>Note:</b><br>{notes_html}</div>')
    else:
        page = page.replace("%%NOTES_BLOCK%%", "")
    return page


def load_meta(batch_dir):
    """Batch folder ki data.json padhta hai (preview ke liye)."""
    p = os.path.join(batch_dir, "data.json")
    if not os.path.isfile(p):
        return None
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def render_preview(batch, n, meta):
    """PDF jaisa dikhne wala HTML preview page banata hai."""
    item = meta["files"][n - 1]
    total = len(meta["files"])
    page = PREVIEW_PAGE
    page = page.replace("%%BATCH%%", quote(batch))
    page = page.replace("%%TITLE%%", html.escape(item.get("title") or "Document"))
    page = page.replace("%%FILENAME%%", html.escape(item.get("file") or ""))
    page = page.replace("%%CREATED%%", html.escape(meta.get("created") or ""))
    page = page.replace("%%BODY%%", html.escape(item.get("body") or ""))
    page = page.replace("%%IDX%%", str(n))
    page = page.replace("%%TOTAL%%", str(total))
    if n > 1:
        page = page.replace("%%PREV_DISABLED%%", "")
        page = page.replace("%%PREV_URL%%", f"/preview/{quote(batch)}/{n - 1}")
    else:
        page = page.replace("%%PREV_DISABLED%%", "disabled")
        page = page.replace("%%PREV_URL%%", "#")
    if n < total:
        page = page.replace("%%NEXT_DISABLED%%", "")
        page = page.replace("%%NEXT_URL%%", f"/preview/{quote(batch)}/{n + 1}")
    else:
        page = page.replace("%%NEXT_DISABLED%%", "disabled")
        page = page.replace("%%NEXT_URL%%", "#")
    return page


def valid_batch(batch):
    """Sirf hamare banaye hue batch folder naam allow karo (safety)."""
    return bool(re.fullmatch(r"batch-\d{8}-\d{6}", batch or ""))


# =====================================================
#  Web server (sirf Python ki built-in library se)
# =====================================================

class Handler(BaseHTTPRequestHandler):
    server_version = "PDFGenerator/1.0"

    def log_message(self, fmt, *args):
        pass  # terminal me kachra mat dikhao

    def send_html(self, text, status=200):
        data = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_bytes_file(self, data, filename, mime, inline=False):
        self.send_response(200)
        self.send_header("Content-Type", mime)
        # Hindi naam wali file bhi sahi se download ho (RFC 5987)
        disp = "inline" if inline else "attachment"
        self.send_header("Content-Disposition",
                         disp + "; filename=\"download" + os.path.splitext(filename)[1] + "\"; "
                         "filename*=UTF-8''" + quote(filename))
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = urlparse(self.path).path

        if path == "/" or path == "/index.html":
            self.send_html(render_form())
            return

        if path == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
            return

        # /result/<batch>  (purana result page dobara dikhao)
        m = re.fullmatch(r"/result/([^/]+)", path)
        if m:
            batch = unquote(m.group(1))
            if not valid_batch(batch):
                self.send_html("<h2>Galat link</h2>", 400)
                return
            batch_dir = os.path.join(OUTPUT_DIR, batch)
            if not os.path.isdir(batch_dir):
                self.send_html("<h2>Folder nahi mila</h2>", 404)
                return
            files = [f for f in sorted(os.listdir(batch_dir)) if f.lower().endswith(".pdf")]
            meta = load_meta(batch_dir)
            if meta and meta.get("files"):
                order = [x["file"] for x in meta["files"] if x["file"] in files]
                if order:
                    files = order
            self.send_html(render_result(len(files), batch, files, []))
            return

        # /preview/<batch>/<number>  (PDF jaisa HTML preview - har jagah chalta hai)
        m = re.fullmatch(r"/preview/([^/]+)/(\d+)", path)
        if m:
            batch = unquote(m.group(1))
            n = int(m.group(2))
            if not valid_batch(batch):
                self.send_html("<h2>Galat link</h2>", 400)
                return
            meta = load_meta(os.path.join(OUTPUT_DIR, batch))
            if not meta or not meta.get("files") or n < 1 or n > len(meta["files"]):
                self.send_html("<h2>Preview nahi mila</h2><a href='/'>Wapas jayein</a>", 404)
                return
            self.send_html(render_preview(batch, n, meta))
            return

        # /view/<batch>/<file>  (browser me asli PDF kholo - apne system par kaam karega)
        m = re.fullmatch(r"/view/([^/]+)/(.+)", path)
        if m:
            batch, fname = unquote(m.group(1)), unquote(m.group(2))
            if not valid_batch(batch) or "/" in fname or "\\" in fname or fname.startswith("."):
                self.send_html("<h2>Galat link</h2>", 400)
                return
            fpath = os.path.join(OUTPUT_DIR, batch, fname)
            if not os.path.isfile(fpath):
                self.send_html("<h2>File nahi mili</h2>", 404)
                return
            with open(fpath, "rb") as f:
                self.send_bytes_file(f.read(), fname, "application/pdf", inline=True)
            return

        # /download/<batch>/<file>
        m = re.fullmatch(r"/download/([^/]+)/(.+)", path)
        if m:
            batch, fname = unquote(m.group(1)), unquote(m.group(2))
            if not valid_batch(batch) or "/" in fname or "\\" in fname or fname.startswith("."):
                self.send_html("<h2>Galat link</h2>", 400)
                return
            fpath = os.path.join(OUTPUT_DIR, batch, fname)
            if not os.path.isfile(fpath):
                self.send_html("<h2>File nahi mili</h2>", 404)
                return
            with open(fpath, "rb") as f:
                self.send_bytes_file(f.read(), fname, "application/pdf")
            return

        # /download-zip/<batch>
        m = re.fullmatch(r"/download-zip/([^/]+)", path)
        if m:
            batch = unquote(m.group(1))
            if not valid_batch(batch):
                self.send_html("<h2>Galat link</h2>", 400)
                return
            batch_dir = os.path.join(OUTPUT_DIR, batch)
            if not os.path.isdir(batch_dir):
                self.send_html("<h2>Folder nahi mila</h2>", 404)
                return
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                for fname in sorted(os.listdir(batch_dir)):
                    if fname.lower().endswith(".pdf"):
                        z.write(os.path.join(batch_dir, fname), fname)
            self.send_bytes_file(buf.getvalue(), f"{batch}.zip", "application/zip")
            return

        self.send_html("<h2>Page nahi mila</h2><a href='/'>Wapas jayein</a>", 404)

    def do_POST(self):
        path = urlparse(self.path).path
        if path != "/generate":
            self.send_html("<h2>Page nahi mila</h2><a href='/'>Wapas jayein</a>", 404)
            return

        try:
            length = int(self.headers.get("Content-Length", 0))
        except ValueError:
            length = 0
        if length > 10 * 1024 * 1024:  # 10MB se bada data mana hai
            self.send_html(render_form(error="Itna bada data ek baar me nahi bhejein!"), 413)
            return
        raw = self.rfile.read(length).decode("utf-8", errors="replace")
        form = parse_qs(raw, keep_blank_values=True)

        def field(name, default=""):
            vals = form.get(name)
            return vals[0] if vals else default

        # --- 1. Ginati ---
        try:
            count = int(field("count", "1"))
        except ValueError:
            count = 1
        count = max(1, min(count, 100))

        # --- 2. Titles ---
        titles = [t.strip() for t in field("titles").splitlines() if t.strip()]
        notes = []
        if len(titles) < count:
            have = len(titles)
            for i in range(have + 1, count + 1):
                titles.append(f"PDF {i}")
            notes.append(f"Titles kam the, isliye baaki PDF ka naam apne aap rakha gaya (PDF {have+1} ...).")
        titles = titles[:count]

        # --- 3. Body ---
        body_mode = field("body_mode", "same")
        if body_mode == "different":
            bodies = [field(f"body_{i}").strip() for i in range(1, count + 1)]
            first = next((b for b in bodies if b), "")
            bodies = [b if b else first for b in bodies]
            if not first:
                self.send_html(render_form(error="Body khaali hai! Kam se kam ek body to likhiye.",
                                           count=count, titles=field("titles")))
                return
        else:
            same_body = field("body_same").strip()
            if not same_body:
                self.send_html(render_form(error="Body khaali hai! Body ka text likhiye.",
                                           count=count, titles=field("titles")))
                return
            bodies = [same_body] * count

        # --- 4. PDF banayo aur save karo ---
        add_number = field("add_number") == "on"
        batch = datetime.now().strftime("batch-%Y%m%d-%H%M%S")
        batch_dir = os.path.join(OUTPUT_DIR, batch)
        os.makedirs(batch_dir, exist_ok=True)

        files = []
        meta = {"created": datetime.now().strftime("%d-%m-%Y %I:%M %p"), "files": []}
        used_names = set()
        for i, (title, body) in enumerate(zip(titles, bodies), start=1):
            base = safe_filename(title, f"PDF-{i}")
            fname = f"{i:02d}-{base}.pdf" if add_number else f"{base}.pdf"
            j = 2
            name_no_ext = fname[:-4]
            while fname in used_names:
                fname = f"{name_no_ext}-{j}.pdf"
                j += 1
            used_names.add(fname)
            with open(os.path.join(batch_dir, fname), "wb") as f:
                f.write(build_pdf(title, body))
            files.append(fname)
            meta["files"].append({"file": fname, "title": title, "body": body})

        # preview page ke liye data save karo (ye ZIP me nahi jayega)
        with open(os.path.join(batch_dir, "data.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False)

        self.send_html(render_result(len(files), batch, files, notes))


def open_browser():
    try:
        webbrowser.open(f"http://127.0.0.1:{PORT}")
    except Exception:
        pass


if __name__ == "__main__":
    print("=" * 55)
    print("  📄 PDF Generator UI chal raha hai! (100% OFFLINE)")
    print(f"  Browser me kholein: http://127.0.0.1:{PORT}")
    print("  Internet ki zaroorat NAHI hai. Band karne: Ctrl+C")
    print("=" * 55)
    Timer(1.2, open_browser).start()  # browser apne aap khol do
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
